print("Hello, welcome to the Band Name Generator!")
print("Hello " + input("What is your name?""\n"))
city = input("What is the name of the city you grew up in?""\n")
pet = input("What is the name of your oldest pet?""\n")
print("Your band name could be "+ city +" " + pet)


